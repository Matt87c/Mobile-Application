package com.example.myinventoryapp;

public class EndUser {
        int id;
        String end_user;
        String phone_number;
        String email;
        String password;

        public EndUser() {
            super();
        }

        public EndUser(int i, String name, String phone, String email, String password) {
            super();
            this.id = i;
            this.end_user = name;
            this.phone_number = phone;
            this.email = email;
            this.password = password;
        }

        public EndUser(String name, String phone, String email, String password) {
            this.end_user = name;
            this.phone_number = phone;
            this.email = email;
            this.password = password;
        }

        public int getId() {
            return id;
        }
        public void setId(int id) {
            this.id = id;
        }
        public String getEnd_user() {
            return end_user;
        }
        public void setEnd_user(String name) {
            this.end_user = name;
        }
        public String getPhone_number() {
            return phone_number;
        }
        public void setPhone_number(String phone) {
            this.phone_number = phone;
        }
        public String getEmail() {
            return email;
        }
        public void setEmail(String email) {
            this.email = email;
        }
        public String getPassword() {
            return password;
        }
        public void setPassword(String pass) {
            this.password = pass;
        }
    }

