package com.example.myinventoryapp;

public class SQLiteDatabaseItems {
}
