package com.example.myinventoryapp;

public class List {
}
