package com.example.myinventoryapp;


public class SMS {
    }

